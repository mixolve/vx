#include "shell.EditorFilterSection.h"
#include "shell.UiConstants.h"
#include "shell.EditorPresetSections.h"

#include <algorithm>


void VxAudioProcessorEditor::updateSectionStates()
{
    constexpr auto globalControlsVisible = true;

    const auto activeFilterCount = getActiveFilterCount();
    const auto activeModule = audioProcessor.getActiveModule();
    auto setComponentVisible = [] (auto* component, const bool shouldShow)
    {
        if (component != nullptr)
            component->setVisible(shouldShow);
    };

    auto setPresetsVisible = [this, setComponentVisible] (const bool shouldShow)
    {
        if (presetsSection == nullptr)
            return;

        setComponentVisible(&presetsSection->presetCombo, shouldShow);
        setComponentVisible(presetsSection->adButton.get(), shouldShow);
        setComponentVisible(presetsSection->saveButton.get(), shouldShow);
        setComponentVisible(presetsSection->renameButton.get(), shouldShow);
        setComponentVisible(presetsSection->defaultButton.get(), shouldShow);
        setComponentVisible(presetsSection->deleteButton.get(), shouldShow);
    };

    auto setEqlFilterSectionsVisible = [this] (const bool shouldShow)
    {
        for (auto& section : filterSections)
        {
            if (section == nullptr)
                continue;

            section->moveUpButton->setVisible(shouldShow);
            section->moveDownButton->setVisible(shouldShow);
            section->header->setVisible(shouldShow);
            section->typeControl->setVisible(shouldShow);
            section->placeControl->setVisible(shouldShow);
            section->slopeControl->setVisible(shouldShow);
            section->frequencyControl->setVisible(shouldShow);
            section->bandwidthControl->setVisible(shouldShow);
            section->gainControl->setVisible(shouldShow);
            section->bypassButton->setVisible(shouldShow);
        }
    };

    auto setEqlControlsVisible = [this, setComponentVisible, setPresetsVisible, setEqlFilterSectionsVisible] (const bool shouldShow)
    {
        filterViewport.setVisible(shouldShow);
        setPresetsVisible(shouldShow);
        setComponentVisible(addFilterButton.get(), shouldShow);
        setComponentVisible(sortPlaceButton.get(), shouldShow);
        setComponentVisible(sortFreqButton.get(), shouldShow);
        setComponentVisible(sortDuoButton.get(), shouldShow);
        setEqlFilterSectionsVisible(shouldShow);
    };

    auto setFftControlsVisible = [this, setComponentVisible] (const bool shouldShow)
    {
        const auto phaseMode = fftDynamicModeButton != nullptr && fftDynamicModeButton->getToggleState();

        fftAnalyserViewport.setVisible(shouldShow);
        setComponentVisible(fftAnalyserComponent.get(), shouldShow);
        setComponentVisible(fftAttackControl.get(), shouldShow);
        setComponentVisible(fftReleaseControl.get(), shouldShow);
        setComponentVisible(fftKneeControl.get(), shouldShow);
        setComponentVisible(fftRatioControl.get(), shouldShow);
        setComponentVisible(fftFloorControl.get(), shouldShow && phaseMode);
        setComponentVisible(fftGeneralProcessorHeader.get(), shouldShow);
        setComponentVisible(fftDspFftSizeControl.get(), shouldShow);
        setComponentVisible(fftDspHopDivisorControl.get(), shouldShow);
        setComponentVisible(fftDspSlopeControl.get(), shouldShow);
        setComponentVisible(fftPhaseImpactControl.get(), shouldShow && phaseMode);
        setComponentVisible(fftDeltaButton.get(), shouldShow);
        setComponentVisible(fftDualMonoLeftThresholdControl.get(), shouldShow);
        setComponentVisible(fftDualMonoLeftAdaptiveControl.get(), shouldShow);
        setComponentVisible(fftDualMonoRightThresholdControl.get(), shouldShow && ! phaseMode);
        setComponentVisible(fftDualMonoRightAdaptiveControl.get(), shouldShow && ! phaseMode);
        setComponentVisible(fftDynamicProcessorHeader.get(), shouldShow);
        setComponentVisible(fftDynamicModeButton.get(), shouldShow);
        setComponentVisible(fftDualMonoLinkButton.get(), shouldShow && ! phaseMode);
        setComponentVisible(fftAdaptiveSettingsButton.get(), shouldShow);
        setComponentVisible(fftAdaptiveOffsetControl.get(), shouldShow && fftAdaptiveSettingsExpanded);
        setComponentVisible(fftAdaptiveAttackControl.get(), shouldShow && fftAdaptiveSettingsExpanded);
        setComponentVisible(fftAdaptiveHoldControl.get(), shouldShow && fftAdaptiveSettingsExpanded);
        setComponentVisible(fftAdaptiveReleaseControl.get(), shouldShow && fftAdaptiveSettingsExpanded);
        setComponentVisible(fftDynamicBypassButton.get(), shouldShow);
        setComponentVisible(fftAnalyserSettingsHeader.get(), shouldShow);
        setComponentVisible(fftAnalyserFftSizeControl.get(), shouldShow);
        setComponentVisible(fftAnalyserOverlapControl.get(), shouldShow);
        setComponentVisible(fftAnalyserLeftControl.get(), shouldShow);
        setComponentVisible(fftAnalyserRightControl.get(), shouldShow);
        setComponentVisible(fftAnalyserRangeLowControl.get(), shouldShow);
        setComponentVisible(fftAnalyserRangeHighControl.get(), shouldShow);
        setComponentVisible(fftAnalyserSlopeControl.get(), shouldShow && ! phaseMode);
        setComponentVisible(fftAnalyserTimeControl.get(), shouldShow);

        if (fftDynamicModeButton != nullptr)
            fftDynamicModeButton->setButtonText(phaseMode ? "PHASE CORR" : "SPECTRAL");

        if (fftDualMonoLeftThresholdControl != nullptr)
            fftDualMonoLeftThresholdControl->setTitleText(phaseMode ? "THRESH" : "L.THRESH");
        if (fftDualMonoLeftAdaptiveControl != nullptr)
            fftDualMonoLeftAdaptiveControl->setTitleText(phaseMode ? "ADAP" : "L.ADAP");
        if (fftDualMonoRightThresholdControl != nullptr)
            fftDualMonoRightThresholdControl->setTitleText("R.THRESH");
        if (fftDualMonoRightAdaptiveControl != nullptr)
            fftDualMonoRightAdaptiveControl->setTitleText("R.ADAP");

        if (fftAdaptiveSettingsButton != nullptr)
            fftAdaptiveSettingsButton->setToggleState(fftAdaptiveSettingsExpanded, juce::dontSendNotification);
        if (fftAdaptiveOffsetControl != nullptr)
            fftAdaptiveOffsetControl->setTitleText("OFFSET");

        if (fftDualMonoLinkButton != nullptr)
        {
            fftDualMonoLinkButton->setButtonText("LINK-LR (STEREO)");
            fftDualMonoLinkButton->setEnabled(true);
        }
    };

    if (clipButton != nullptr)
    {
        clipButton->setVisible(globalControlsVisible);
        clipButton->setButtonText("C");
        clipButton->setToggleState(false, juce::dontSendNotification);
    }

    if (footerTab != nullptr)
        footerTab->setVisible(true);

    if (hostButton != nullptr)
    {
        hostButton->setVisible(globalControlsVisible);
        hostButton->setToggleState(hostParametersExpanded, juce::dontSendNotification);
    }

    refreshModuleTabButton();

    if (moduleTabButton != nullptr)
    {
        const auto module = audioProcessor.getActiveModule();
        const auto active = activeModule == module;
        const auto shouldShow = module != VxAudioProcessor::ActiveModule::none;

        moduleTabButton->setVisible(shouldShow);
        moduleTabButton->setButtonText(juce::String(VxAudioProcessor::stateIdForModule(module)).toUpperCase());
        moduleTabButton->setToggleState(active, juce::dontSendNotification);
    }

    const auto hostParametersVisible = hostParametersExpanded;

    hostParametersViewport.setVisible(hostParametersVisible);

    if (moduleAddButton != nullptr)
    {
        const auto noModuleLoaded = audioProcessor.getActiveModule() == VxAudioProcessor::ActiveModule::none;
        moduleAddButton->setVisible(noModuleLoaded && ! hostParametersExpanded);
        moduleAddButton->setEnabled(noModuleLoaded);
    }

    if (globalBypassButton != nullptr)
        globalBypassButton->setVisible(globalControlsVisible);

    if (undoButton != nullptr)
        undoButton->setVisible(globalControlsVisible);

    if (redoButton != nullptr)
        redoButton->setVisible(globalControlsVisible);

    if (abCompareButton != nullptr)
        abCompareButton->setVisible(globalControlsVisible);

    for (auto& hostSlotButton : hostSlotButtons)
        if (hostSlotButton != nullptr)
            hostSlotButton->setVisible(hostParametersVisible);

    if (tlsModuleEditor != nullptr)
        tlsModuleEditor->setVisible(tlsModuleLoaded);

    if (dynModuleEditor != nullptr)
        dynModuleEditor->setVisible(dynModuleLoaded);

    if (trsModuleEditor != nullptr)
        trsModuleEditor->setVisible(trsModuleLoaded);

    if (! eqlModuleLoaded && ! fftModuleLoaded && ! tlsModuleLoaded && ! dynModuleLoaded && ! trsModuleLoaded)
    {
        setEqlControlsVisible(false);
        setFftControlsVisible(false);
        setComponentVisible(tlsModuleEditor.get(), false);
        setComponentVisible(dynModuleEditor.get(), false);
        setComponentVisible(trsModuleEditor.get(), false);

        return;
    }

    if (tlsModuleLoaded || dynModuleLoaded || trsModuleLoaded)
    {
        setEqlControlsVisible(false);
        setFftControlsVisible(false);
        setComponentVisible(tlsModuleEditor.get(), tlsModuleLoaded);
        setComponentVisible(dynModuleEditor.get(), dynModuleLoaded);
        setComponentVisible(trsModuleEditor.get(), trsModuleLoaded);

        return;
    }

    if (fftModuleLoaded)
    {
        setPresetsVisible(false);
        setFftControlsVisible(true);
        filterViewport.setVisible(true);
        setComponentVisible(addFilterButton.get(), false);
        setComponentVisible(sortPlaceButton.get(), false);
        setComponentVisible(sortFreqButton.get(), false);
        setComponentVisible(sortDuoButton.get(), false);
        setEqlFilterSectionsVisible(false);

        return;
    }

    setFftControlsVisible(false);

    updateUndoRedoButtons();
    const auto canSortFilters = activeFilterCount > 1;

    if (sortPlaceButton != nullptr)
    {
        sortPlaceButton->setVisible(eqlModuleLoaded);
        sortPlaceButton->setEnabled(canSortFilters);
        sortPlaceButton->setAlpha(canSortFilters ? 1.0f : 0.45f);
    }

    if (sortFreqButton != nullptr)
    {
        sortFreqButton->setVisible(eqlModuleLoaded);
        sortFreqButton->setEnabled(canSortFilters);
        sortFreqButton->setAlpha(canSortFilters ? 1.0f : 0.45f);
    }

    if (sortDuoButton != nullptr)
    {
        sortDuoButton->setVisible(eqlModuleLoaded);
        sortDuoButton->setEnabled(canSortFilters);
        sortDuoButton->setAlpha(canSortFilters ? 1.0f : 0.45f);
    }

    filterViewport.setVisible(eqlModuleLoaded);
    setPresetsVisible(eqlModuleLoaded);

    for (int filterIndex = 0; filterIndex < VxAudioProcessor::maxEqlFilterCount; ++filterIndex)
    {
        auto* section = filterSections[static_cast<size_t>(filterIndex)].get();

        if (section == nullptr)
            continue;

        const auto orderPosition = getFilterOrderPositionForIndex(filterIndex);
        const auto isActive = eqlModuleLoaded && orderPosition >= 0;
        const auto sectionExpanded = isActive && section->expanded;
        const auto filterType = section->getFilterType();
        const auto isVolume = filterType == EqlModuleProcessor::FilterType::volume;
        const auto isBell = filterType == EqlModuleProcessor::FilterType::bell;
        const auto isPhasePlace = section->getPlace() >= 5 && section->getPlace() <= 7;
        const auto bandwidthInactive = section->isBandwidthInactiveAtCurrentSlope();
        const auto slopeInactive = section->isSlopeInactive();
        const auto gainInactive = section->isGainInactive();
        const auto filterOrderOff = filterType == EqlModuleProcessor::FilterType::bell
            && section->slopeControl->getSelectedChoiceIndex() == 0;
        const auto canMoveUp = isActive && orderPosition > 0;
        const auto canMoveDown = isActive && orderPosition + 1 < activeFilterCount;

        section->updatePlaceChoicesForType(false);
        section->moveUpButton->setVisible(isActive);
        section->moveUpButton->setEnabled(canMoveUp);
        section->moveUpButton->setAlpha(canMoveUp ? 1.0f : 0.45f);
        section->moveDownButton->setVisible(isActive);
        section->moveDownButton->setEnabled(canMoveDown);
        section->moveDownButton->setAlpha(canMoveDown ? 1.0f : 0.45f);
        if (auto* eqlProcessor = getActiveEqlProcessor())
            section->header->setButtonText(eqlProcessor->getFilterHeaderText(filterIndex, orderPosition));
        else
            section->header->setButtonText({});
        section->header->setVisible(isActive);
        section->header->setToggleState(sectionExpanded, juce::dontSendNotification);
        section->typeControl->setVisible(sectionExpanded);
        section->placeControl->setVisible(sectionExpanded);
        section->slopeControl->setVisible(sectionExpanded);
        section->slopeControl->setInteractionEnabled(! slopeInactive);
        if (slopeInactive || filterOrderOff)
            section->slopeControl->setOverrideText("OFF");
        else
            section->slopeControl->clearOverrideText();
        section->frequencyControl->setVisible(sectionExpanded);
        section->updateFrequencyRangeForType();
        section->frequencyControl->setInteractionEnabled(! isVolume);
        if (isVolume)
            section->frequencyControl->setOverrideText("OFF");
        else
            section->frequencyControl->clearOverrideText();
        section->bandwidthControl->setVisible(sectionExpanded);
        section->bandwidthControl->setInteractionEnabled(isBell && ! bandwidthInactive);
        if (isBell && ! bandwidthInactive)
            section->bandwidthControl->clearOverrideText();
        else
            section->bandwidthControl->setOverrideText("OFF");
        section->gainControl->setVisible(sectionExpanded);
        section->setGainDisplaysDegrees(isPhasePlace && ! gainInactive);
        section->gainControl->setInteractionEnabled(! gainInactive);
        if (gainInactive)
            section->gainControl->setOverrideText("OFF");
        else
            section->gainControl->clearOverrideText();
        section->bypassButton->setVisible(isActive);
    }

    if (addFilterButton != nullptr)
    {
        addFilterButton->setVisible(eqlModuleLoaded);
        addFilterButton->setEnabled(true);
        addFilterButton->setAlpha(1.0f);
    }
}
