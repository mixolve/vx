#include "module.eqe.ProcessorSupport.h"

juce::String formatDecibelValue(const float value)
{
    return juce::String::formatted("%.2f dB", static_cast<double>(value));
}

juce::String formatFrequencyValue(const float value)
{
    return juce::String::formatted("%.2f Hz", static_cast<double>(value));
}

juce::String formatBandwidthValue(const float value)
{
    return juce::String::formatted("%.2f oct", static_cast<double>(value));
}

juce::String makeFilterParameterId(const char* suffix, const int filterIndex)
{
    return "filter_" + juce::String(filterIndex + 1) + "_" + suffix;
}

int clampActiveFilterCount(const int filterCount)
{
    return juce::jlimit(0, EqeModuleProcessor::maxFilterCount, filterCount);
}

juce::String filterTypeDisplayPrefix(const EqeModuleProcessor::FilterType type)
{
    switch (type)
    {
        case EqeModuleProcessor::FilterType::lowShelf: return "LSH";
        case EqeModuleProcessor::FilterType::lowCut: return "LCT";
        case EqeModuleProcessor::FilterType::highCut: return "HCT";
        case EqeModuleProcessor::FilterType::highShelf: return "HSH";
        case EqeModuleProcessor::FilterType::tilt: return "FTL";
        case EqeModuleProcessor::FilterType::volume: return "VOL";
        case EqeModuleProcessor::FilterType::bell:
        default: return "BEL";
    }
}
